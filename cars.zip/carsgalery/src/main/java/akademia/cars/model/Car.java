package akademia.cars.model;


import lombok.*;

//@Getter
//@Setter
//@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data //to samo co gett, sett, toStr
public class Car {

    private String brand;
    private String model;
    private String power;
    private String year;
    private String picture;

}
